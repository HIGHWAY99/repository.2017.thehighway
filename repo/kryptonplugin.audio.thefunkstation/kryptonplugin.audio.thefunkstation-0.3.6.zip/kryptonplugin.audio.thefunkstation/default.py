### ############################################################################################################
###	#	
### # Project: 			#		TheFunctStation.com - by The Highway 2013-2017.
### # Author: 			#		The Highway
### # Version:			#		v0.3.6
### # Description: 	#		http://www.thefunkstation.com/		|		http://listento.thefunkstation.com:8000/ 
###	#	
### ############################################################################################################
### ############################################################################################################
##### Imports #####
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,xbmcvfs
import HTMLParser, htmlentitydefs
import copy

from teh_2017_tools 		import *
import plugintools
from config 			import *

_artFanart=fanart; _artIcon=ICON; _artPath=artPath;

#try: 		import StorageServer
#except: import storageserverdummy as StorageServer
#from t0mm0_common_addon 				import Addon
from t0mm0_common_net 					import Net
net=Net();
#from teh_tools 		import *
##### /\ ##### Imports #####
### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
##### Functions #####
def eod(): plugintools.close_item_list()
def art(f,fe=ps('default_art_ext')): return xbmc.translatePath(os.path.join(_artPath,f+fe)) ### for Making path+filename+ext data for Art Images. ###
_artDead=ps('art_dead'); _artSun=ps('art_sun'); 
def deadNote(header='',msg='',delay=5000,image=_artDead): notification(header,msg,delay,image)
def sunNote( header='',msg='',delay=5000,image=_artSun):
	header=cFL(header,ps('cFL_color')); msg=cFL(msg,ps('cFL_color2'))
	notification(header,msg,delay,image)
def messupText(t,_html=False,_ende=False,_a=False,Slashes=False):
	if (_html==True): t=ParseDescription(HTMLParser.HTMLParser().unescape(t))
	if (_ende==True): t=t.encode('ascii', 'ignore'); t=t.decode('iso-8859-1')
	#if (_a==True): t=_addon.decode(t); t=_addon.unescape(t)
	if (Slashes==True): t=t.replace( '_',' ')
	return t




##### /\ ##### Functions #####


### ############################################################################################################
### ############################################################################################################
##### Queries #####
#try: _paramB=plugintools.get_params()
#except: _paramB={}
try: _param=plugintools.get_params()
except: _param={}
try: _param['mode']=_param['action']
except: _param['mode']=''


#_param={}
#_param['mode']=addpr('mode',''); _param['url']=urllib.unquote_plus(addpr('url','')); _param['pagesource'],_param['pageurl'],_param['pageno'],_param['pagecount']=addpr('pagesource',''),addpr('pageurl',''),addpr('pageno',0),addpr('pagecount',1)
#_param['img']=addpr('img',''); _param['fanart']=addpr('fanart',''); _param['thumbnail'],_param['thumbnail'],_param['thumbnail']=addpr('thumbnail',''),addpr('thumbnailshow',''),addpr('thumbnailepisode','')
#_param['section']=addpr('section','movies'); _param['title']=addpr('title',''); _param['year']=addpr('year',''); _param['genre']=addpr('genre','')
#_param['by']=addpr('by',''); _param['letter']=addpr('letter',''); _param['showtitle']=addpr('showtitle',''); _param['showyear']=addpr('showyear',''); _param['listitem']=addpr('listitem',''); _param['infoLabels']=addpr('infoLabels',''); _param['season']=addpr('season',''); _param['episode']=addpr('episode','')
#_param['pars']=addpr('pars',''); _param['labs']=addpr('labs',''); _param['name']=addpr('name',''); _param['thetvdbid']=addpr('thetvdbid','')
#_param['plot']=addpr('plot',''); _param['tomode']=addpr('tomode',''); _param['country']=addpr('country','')
#_param['thetvdb_series_id']=addpr('thetvdb_series_id',''); _param['dbid']=addpr('dbid',''); _param['user']=addpr('user','')
#_param['subfav']=addpr('subfav',''); _param['episodetitle']=addpr('episodetitle',''); _param['special']=addpr('special',''); _param['studio']=addpr('studio','')

#_param['']=_addon.queries.get('','')
#_param['']=_addon.queries.get('','')
##_param['pagestart']=addpr('pagestart',0)
##### /\

### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
##### Menus #####
def Menu_MainMenu(): #The Main Menu
	WhereAmI('@ the Main Menu')
	#plugintools.log('@ the Main Menu')
	##plugintools.add_item( action="PlayURL",title="Listen",url="http://listento.thefunkstation.com:8000/",thumbnail=ps('_button_url'),folder=False );
	##eod();
	#http://listento.thefunkstation.com:8000/listen.pls?sid=1
	#plugintools.add_item(action="PlayURL",url="http://listento.thefunkstation.com:8000/listen.pls?sid=1",title=cFL_('Listen (on Krypton4)',ps('cFL_color')),info_labels={'mode': 'PlayURL','url':'http://listento.thefunkstation.com:8000/listen.pls?sid=1'},folder=False		,fanart=_artFanart,thumbnail=art('Listen'),isPlayable=False)
	#plugintools.add_item(action="PlayURL",url="http://listento.thefunkstation.com:8000/listen.pls?sid=1",title=cFL_('Listen (on Krypton3)',ps('cFL_color')),info_labels={'mode': 'PlayURL','url':'http://listento.thefunkstation.com:8000/listen.pls?sid=1'},folder=True		,fanart=_artFanart,thumbnail=art('Listen'),isPlayable=False)
	plugintools.add_item(action="PlayURL",url="http://listento.thefunkstation.com:8000/listen.pls?sid=1",title=cFL_('Listen (on Krypton)',ps('cFL_color')),info_labels={'mode': 'PlayURL','url':'http://listento.thefunkstation.com:8000/listen.pls?sid=1'},folder=True		,fanart=_artFanart,thumbnail=art('Listen'),isPlayable=True)
	#plugintools.add_item(action="PlayURL",url="http://listento.thefunkstation.com:8000/listen.pls?sid=1",title=cFL_('Listen (on Krypton)',ps('cFL_color')),info_labels={'mode': 'PlayURL','url':'http://listento.thefunkstation.com:8000/listen.pls?sid=1'},folder=False		,fanart=_artFanart,thumbnail=art('Listen'),isPlayable=True)
	plugintools.add_item(action="PlayURL",url="http://listento.thefunkstation.com:8000/",title=cFL_('Listen (on Gotham)',ps('cFL_color')),info_labels={'mode': 'PlayURL','url':'http://listento.thefunkstation.com:8000/'},folder=False		,fanart=_artFanart,thumbnail=art('Listen'),isPlayable=True)
	#plugintools.add_item(action="PlayURLPAPlayer",url="http://listento.thefunkstation.com:8000/",title=cFL_('Listen (on Frodo)',ps('cFL_color')),info_labels={'mode': 'PlayURLPAPlayer','url':'http://listento.thefunkstation.com:8000/'},folder=False		,fanart=_artFanart, thumbnail=art('Listen2'),isPlayable=True)
	#
	plugintools.add_item(action="SongHistory",url='http://listento.thefunkstation.com:8000/played.html',title=cFL_('Song History',ps('cFL_color3')),info_labels={'mode': 'SongHistory','url':'http://listento.thefunkstation.com:8000/played.html'},folder=True		,fanart=_artFanart, thumbnail=art('SongHistory'))
	plugintools.add_item(action="Status",url='http://listento.thefunkstation.com:8000/index.html',title=cFL_('Status',ps('cFL_color3')),info_labels={'mode': 'Status','url':'http://listento.thefunkstation.com:8000/index.html'},folder=True		,fanart=_artFanart, thumbnail=art('Status'))
	#plugintools.add_item(action="SlideShowStart",title=cFL_('Start SlideShow (LastFM Packaged)',ps('cFL_color5')),info_labels={'mode': 'SlideShowStart'},folder=True		,fanart=_artFanart, thumbnail=art('SlideShow'))
	#
	#plugintools.add_item(action="Settings",title=cFL_('Plugin Settings',ps('cFL_color2')),info_labels={'mode': 'Settings'},folder=True		,fanart=_artFanart, thumbnail=art('Settings'))
	### ############ 
	#set_view('list',addst('default-view')); 
	#myNote("Test Main Menu","Just a test",200)
	eod()
	### ############ 

##### /\ ##### Menus #####

def SongHistory(url):
	if (url==''): deadNote('URL Error', 'No URL was Found.'); return
	html=''; WhereAmI('@ Song History -- url: %s' % url)
	try: html=net.http_GET(url).content
	except: 
		try: html=getURL(url)
		except: 
			try: html=getURLr(url,_domain_url)
			except: html=''
	if (html=='') or (html=='none') or (html==None): deb('Error','Problem with page'); deadNote('Results:  '+section,'No results were found.'); return
	deb('Length of HTML',str(len(html)))
	html2=(html.split('<tr><td><b>Played @</b></td><td><b>Song Title</b></td></tr>')[1]).split('</table>')[0]
	html2=html2.replace('</td><td style="padding: 0 1em;">',' ')
	html2=html2.replace('<b>','[B]').replace('<B>','[B]').replace('</b>','[/B]').replace('</B>','[/B]')
	html2=html2.replace('<i>','[I]').replace('<I>','[I]').replace('</i>','[/I]').replace('</I>','[/I]')
	html2=html2.replace('<tr>','').replace('<TR>','').replace('</tr>','[CR]').replace('</TR>','[CR]')
	html2=html2.replace('</td><td>','     ').replace('</TD><TD>','     ')
	html2=html2.replace('<td>','').replace('<TD>','').replace('</td>','').replace('</TD>','')
	html2=html2.replace('[B]Current Song[/B]','[B][COLOR grey]  << Current Song[/COLOR][/B]')
	html2=html2.replace("&apos;","'").replace("&nbsp;"," ").replace("&amp;","&")
	#html2=html2.replace('','')
	#try: _addon.resolve_url(url)
	#except: t=''
	TextBox2().load_string( html2 , cFL('Song History',ps('cFL_color2')) )
	#eod()

def Status(url):
	if (url==''): deadNote('URL Error', 'No URL was Found.'); return
	html=''; WhereAmI('@ Status -- url: %s' % url)
	try: html=net.http_GET(url).content
	except: 
		try: html=getURL(url)
		except: 
			try: html=getURLr(url,_domain_url)
			except: html=''
	if (html=='') or (html=='none') or (html==None): deb('Error','Problem with page'); deadNote('Results:  '+section,'No results were found.'); return
	deb('Length of HTML',str(len(html)))
	#html2=(html.split('<table cellpadding=5 cellspacing=0 border=0 width=100%><tr><td bgcolor=#000025 colspan=2 align=center><font class=ST>Current Stream Information</font></td></tr></table><table cellpadding=2 cellspacing=0 border=0 align=center>')[1]).split('</table>')[0]
	#html2=html2.replace('<b>','[B]').replace('<B>','[B]').replace('</b>','[/B]').replace('</B>','[/B]').replace('<i>','[I]').replace('<I>','[I]').replace('</i>','[/I]').replace('</I>','[/I]').replace('<tr>','').replace('<TR>','').replace('</tr>','[CR]').replace('</TR>','[CR]').replace('</td><td>','     ').replace('</TD><TD>','     ').replace('<td>','').replace('<TD>','').replace('</td>','').replace('</TD>','')
	#html2=html2.replace('<td width=100 nowrap>','').replace('<font class=default>','').replace('</font>','')
	#html2=html2.replace('<br>','[CR]').replace('<BR>','[CR]').replace('&nbsp;',' ').replace('[/B][/B]','[/B]')
	#html2=html2.replace('</a>','[/COLOR]').replace('<a href="','[COLOR maroon]').replace('">','[/COLOR]     [COLOR red]')
	html2=''
	try:
		if '<td>Stream Status: </td><td>' in html: html2=html.split('<td>Stream Status: </td><td>')[1].split('</td>')[0]
		html2=html2.replace('<b>','').replace('</b>','').replace('<B>','').replace('</B>','')
	except: html2=''
	#html2=html2.replace('','')
	#try: _addon.resolve_url(url)
	#except: t=''
	TextBox2().load_string( html2 , cFL('Song History',ps('cFL_color2')) )
	#eod()








### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
##### Player Functions #####
def PlayURL(url):
	#LogToMyFile(str(url));
	#play=xbmc.Player(xbmc.PLAYER_CORE_AUTO) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	### AUTO|DVDPLAYER|MPLAYER|PAPLAYER
	#PlayerMethod=addst("core-player")
	#WhereAmI('@ PlayURL -- url: %s -- with: %s' % (url,str(PlayerMethod)))
	#if   (PlayerMethod=='DVDPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_DVDPLAYER
	#elif (PlayerMethod=='MPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_MPLAYER
	#elif (PlayerMethod=='PAPLAYER'): PlayerMeth=xbmc.PLAYER_CORE_PAPLAYER
	#else: PlayerMeth=xbmc.PLAYER_CORE_AUTO
	#play=xbmc.Player(PlayerMeth) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	play=xbmc.Player()
	plugintools.log('@ Attempting to play: '+str(url))
	#myNote("Test Play",url,300)
	#try: _addon.resolve_url(url)
	#except: t=''
	#try: 
	play.play(url)
	#try: plugintools.play_resolved_url(url)
	#try: plugintools.direct_play(url)
	#except: t=''	
	#except: t=''

def PlayURLAuto(url):
	play=xbmc.Player(xbmc.PLAYER_CORE_AUTO) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	#try: _addon.resolve_url(url)
	#except: t=''
	try: play.play(url)
	except: t=''

def PlayURLPAPlayer(url):
	play=xbmc.Player(xbmc.PLAYER_CORE_PAPLAYER) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	#try: _addon.resolve_url(url)
	#except: t=''
	try: play.play(url)
	except: t=''

def PlayPlayList(url):
	thumbnail=ps('_playlist_img') #_artIcon
	name='The Funk Station'
	liz=xbmcgui.ListItem(name,iconImage=thumbnail,thumbnailImage=thumbnail)
	liz.setInfo('music',{'Title':name}) # ,"Duration" : duration
	liz.setProperty('mimetype', 'audio/mpeg')
	liz.setProperty('IsPlayable', 'true')	#play=xbmc.Player(xbmc.PLAYER_CORE_AUTO) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
	pl.clear()    
	pl.add(url, liz)
	#xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(pl)
	#play=xbmc.Player(xbmc.PLAYER_CORE_AUTO) ### xbmc.PLAYER_CORE_AUTO | xbmc.PLAYER_CORE_DVDPLAYER | xbmc.PLAYER_CORE_MPLAYER | xbmc.PLAYER_CORE_PAPLAYER
	play=xbmc.Player(xbmc.PLAYER_CORE_MPLAYER)
	#try: _addon.resolve_url(url)
	#except: t=''
	try: play.play(pl) # url
	except: t=''
	#try: _addon.resolve_url(pl)
	#except: t=''







### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
##### Modes #####
def check_mode(mode=''):
	deb('Mode',mode)
	#plugintools.log('@ mode: '+str(mode))
	#print _param;
	#LogToMyFile("A"+str(_param));
	#LogToMyFile("B"+str(_paramB));
	
	if (mode=='') or (mode=='main') or (mode=='MainMenu'): Menu_MainMenu()
	
	#elif (mode=='PlayVideo'): 						PlayVideo(_param['url'], _param['infoLabels'], _param['listitem'])
	#elif (mode=='PlaySong'): 							PlaySong(_param['url'], _param['title'], _param['img'])
	elif (mode=='PlayURL'): 							PlayURL(_param['url'])
	elif (mode=='PlayURLAuto'): 					PlayURLAuto(_param['url'])
	elif (mode=='PlayURLPAPlayer'): 			PlayURLPAPlayer(_param['url'])
	elif (mode=='PlayPlayList'): 					PlayPlayList(_param['url'])
	#elif (mode=='Settings'): 							_addon.addon.openSettings() #_plugin.openSettings()
	#elif (mode=='ResolverSettings'): 			urlresolver.display_settings()
	#elif (mode=='LoadCategories'): 				Menu_LoadCategories(_param['section'])
	#elif (mode=='GetTitles'): 						listItems(_param['section'], _param['url'], _param['pageno'], _param['pagecount'], _param['genre'], _param['year'], _param['title'])
	elif (mode=='TextBoxFile'): 					TextBox2().load_file(_param['url'],_param['title']); eod()
	elif (mode=='TextBoxUrl'):  					TextBox2().load_url( _param['url'],_param['title']); eod()
	elif (mode=='Search'):  							doSearchNormal(_param['section'],_param['title'])
	elif (mode=='sunNote'):  		   				sunNote( header=_param['title'],msg=_param['plot'])
	elif (mode=='deadNote'):  		   			deadNote(header=_param['title'],msg=_param['plot'])
	#elif (mode=='Download'): 							print _param; DownloadRequest(_param['section'], _param['url'],_param['img'],_param['studio']); eod()
	#elif (mode=='DownloadStop'): 					DownloadStop(); eod()
	#elif (mode=='ChangeFanartList'):			ChangeFanartList(_param['section'],_param['subfav'],_param['url'],_param['fanart'],_param['img'],_param['studio'])
	#elif (mode=='ChangeFanartUpdate'):		ChangeFanartUpdate(_param['section'],_param['subfav'],_param['url'],_param['title'])
	elif (mode=='SongHistory'):						SongHistory(_param['url'])
	elif (mode=='Status'):								Status(_param['url'])
	elif (mode=='SlideShowStart'):				path = os.path.join(addonPath, 'slideshow.py'); xbmc.executebuiltin('XBMC.RunScript(%s)' % path)
	else: deadNote(header='Mode:  "'+mode+'"',msg='[ mode ] not found.'); initDatabase(); Menu_MainMenu()

# {'showyear': '', 'infoLabels': "
# {'Plot': '', 'Episode': '11', 'Title': u'Transformers Prime', 'IMDbID': '2961014', 'host': 'filenuke.com', 
# 'IMDbURL': 'http://anonym.to/?http%3A%2F%2Fwww.imdb.com%2Ftitle%2Ftt2961014%2F', 
# 'ShowTitle': u'Transformers Prime', 'quality': 'HDTV', 'Season': '3', 'age': '25 days', 
# 'Studio': u'Transformers Prime  (2010):  3x11 - Persuasion', 'Year': '2010', 'IMDb': '2961014', 
# 'EpisodeTitle': u'Persuasion'}", 'thetvdbid': '', 'year': '', 'special': '', 'plot': '', 
# 'img': 'http://static.solarmovie.so/images/movies/1659175_150x220.jpg', 'title': '', 'fanart': '', 'dbid': '', 'section': 'tv', 'pagesource': '', 'listitem': '<xbmcgui.ListItem object at 0x14C799B0>', 'episodetitle': '', 'thumbnail': '', 'thetvdb_series_id': '', 'season': '', 'labs': '', 'pageurl': '', 'pars': '', 'user': '', 'letter': '', 'genre': '', 'by': '', 'showtitle': '', 'episode': '', 'name': '', 'pageno': 0, 'pagecount': 1, 'url': '/link/show/1466546/', 'country': '', 'subfav': '', 'mode': 'Download', 'tomode': ''}

##### /\ ##### Modes #####
### ############################################################################################################
#deb('param >> studio',_param['studio'])
#deb('param >> season',_param['season'])
#deb('param >> section',_param['section'])
#deb('param >> img',_param['img'])
#deb('param >> showyear',_param['showyear'])
#deb('param >> showtitle',_param['showtitle'])
#deb('param >> title',_param['title'])
#deb('param >> url',_param['url']) ### Simply Logging the current query-passed / param -- URL
check_mode(_param['mode']) ### Runs the function that checks the mode and decides what the plugin should do. This should be at or near the end of the file.
### ############################################################################################################
### ############################################################################################################
### ############################################################################################################
